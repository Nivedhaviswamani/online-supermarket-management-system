package project;

public class StationaryProduct extends Product{
	public StationaryProduct()
	{
		setTableName("stationary");
		setCategory("stationary");
	}


}
