package project;
import java.util.*;
import java.sql.*;
public class SignUpPage {
	Connection conn=null;
	String email,password,tableName="";
	protected void setEmail(String email)
	{this.email=email;}
	protected String getEmail()
	{return email;}
	protected void setPassword(String password)
	{this.password=password;}
	protected String getPassword()
	{return password;}
	protected void setTableName(String tableName)
	{this.tableName=tableName;}
	protected String getTableName()
	{return tableName;}
public SignUpPage()
{
	Connections1 c1=new Connections1();
	conn=c1.connect();
}
protected String signIn()
{
	String id="";
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Your email:");
	String tempEmail=sc.next();
	setEmail(tempEmail);
	System.out.println("Enter the password:");
	String tempPassword=sc.next();
	setPassword(tempPassword);
	String sql1="Select * from "+getTableName()+" where email='"+getEmail()+"';";
	try(Statement stmt=conn.createStatement())
	{
		try(ResultSet rs=stmt.executeQuery(sql1))
		{
			while(rs.next())
			{
				tempEmail=rs.getString(1);
				tempPassword=rs.getString(2);
			}
			Password p=new Password();
			boolean equal=p.checkPassword(password,tempPassword);
				if(equal)
                {
                id=getEmail();
               
                }
                else
                
                id="exist";
                	}
				
		
		catch(Exception e) {
		e.printStackTrace();}
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}

	return id;
}


}

