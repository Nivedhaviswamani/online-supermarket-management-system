package project;
import java.sql.*;
import java.util.*;
public class Product {
	String pId,pName,category,pBrand,tableName;
	long price,qty;
	Connection conn=null;
public Product()
{
	Connections1 c1=new Connections1();
	conn=c1.connect();
}
public String getpId() {
    return pId;
}

public void setpId(String pId) {
    this.pId = pId;
}

// Getter and Setter for pName
public String getpName() {
    return pName;
}

public void setpName(String pName) {
    this.pName = pName;
}

// Getter and Setter for category
public String getCategory() {
    return category;
}

public void setCategory(String category) {
    this.category = category;
}

// Getter and Setter for pBrand
public String getpBrand() {
    return pBrand;
}

public void setpBrand(String pBrand) {
    this.pBrand = pBrand;
}

// Getter and Setter for tableName
public String getTableName() {
    return tableName;
}

public void setTableName(String tableName) {
    this.tableName = tableName;
}
public long getPrice() {
    return price;
}

public void setPrice(long price) {
    this.price = price;
}

// Getter and Setter for qty
public long getQty() {
    return qty;
}

public void setQty(long qty) {
    this.qty = qty;
}
public void add()
{
	Scanner sc=new Scanner(System.in);
	System.out.print("Product ID: ");
    setpId(sc.nextLine());

    System.out.print("Product Name: ");
   setpName(sc.nextLine());

    System.out.print("Brand: ");
    setpBrand(sc.nextLine());
    
    System.out.print("Price: ");
    setPrice(sc.nextLong());

    System.out.print("Quantity: ");
    setQty(sc.nextLong());
    try(Statement stmt=conn.createStatement())
    {
 	   String q1="Insert  into "+getTableName()+" values('"+getpId()+"','"+getpName()+"','"+getpBrand()+"','"+getPrice()+"','"+getQty()+"');";
 	   int rowsAffected=stmt.executeUpdate(q1);
 	   if(rowsAffected>0)
 	   {
 		   System.out.println("Product Added ");
 		   
 	   }
 	   else
 		   System.out.println("sorry Couldn't add");
    }
    catch(Exception e)
    {
 	   e.printStackTrace();
    }
     
}
public void update()
{
	String column="";
	Scanner sc=new Scanner(System.in);
	boolean outFlag=true,inFlag=true,f=false;
	while(outFlag) {
	System.out.print("Enter the ProductId you want to update:(enter n to terminate)");
	String id=sc.next();
	if(id.equalsIgnoreCase("n"))
	{
		outFlag=false;
		break;
	}
	String tempId="";
	setpId(id);
	String q1="select pId from "+getTableName()+" where pId='"+getpId()+"';";
	try(Statement stmt=conn.createStatement())
	{
		try(ResultSet rs=stmt.executeQuery(q1))
		{
			while(rs.next())
			{
				tempId=rs.getString(1);
			}
			if(getpId().equals(tempId))
			{
				f=true;
			}
		}
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	if(f)
	{
		while(inFlag)
		{
			System.out.print("Enter 1 to update pName,2 to update pBrand,3-price,4 to update qty,5 to quit");
			String n=sc.next();
			switch(n)
			{
			case "1":
				column="pName";
				break;
			case "2":
				column="pbrand";
				break;
			case "3":
				column="price";
				break;
			case "4":
				column="qty";
				break;
			case "5":
				inFlag=false;
				break;	
				
			}
			if(!inFlag)
				break;
			if(column.equals("price") ||column.equals("qty") )
			{	long amt=sc.nextLong();
			q1="update "+getTableName()+" set "+column+"='"+amt+"' where pId='"+getpId()+"';";
			}
			
			else
			{
				System.out.println("Enter new "+column);
				String s=sc.nextLine();
				q1="update "+getTableName()+" set "+column+"='"+s+"' where pId='"+getpId()+"';";

			}
			
			
			try(Statement stmt=conn.createStatement())
			{
				int rowsAff=stmt.executeUpdate(q1);
				if(rowsAff>0)
					System.out.println(column+" updated successfully");
				else
					System.out.println("coudn't update");
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
	}
	}
}
public void delete()
{
	Scanner sc=new Scanner(System.in);
	String q1="";
	boolean flag=true;
	while(flag) {
		System.out.println("1 delete by pId,2 delete by pname,3 delete by brand,4 exit");
		String ip=sc.next();
		if(ip.equals("4"))
		{
			flag=false;
			break;
		}
		else if(ip.equals("1")) {
	System.out.println("Enter the pId you want to delete:");
	String id=sc.next();
	setpId(id);
	q1="Delete from "+getTableName()+" where pId='"+getpId()+"';";
		}
		else if(ip.equals("2"))
		{
			System.out.println("Enter the product name in which  you want to delete all the products:");
			String dept=sc.next();
			setpName(dept);
			q1="Delete from "+getTableName()+" where pName='"+getpName()+"';";
		}
		else if(ip.equals("3"))
		{
			System.out.println("Enter the brand name  you want to delete:");
			String id=sc.next();
			setpBrand(id);
			q1="Delete from "+getTableName()+" where pBrand='"+getpBrand()+"';";
		}
		else
		{
			System.out.println("Enter correct input");
			continue;
		}
	try(Statement stmt=conn.createStatement())
	{
		int rowsAff=stmt.executeUpdate(q1);
		if(rowsAff>0)
			System.out.println("Deleted successfully");
		else
			System.out.println("coudn't delete");
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	
}
}
public void view(String type)
{
	String q1="";
	if(type.equalsIgnoreCase("all"))
	q1="select * from "+getTableName()+"';";
	else if(type.equalsIgnoreCase("available"))
		q1="select * from "+getTableName()+"' where qty>0;";
	else if(type.equalsIgnoreCase("NotAvailable"))
		q1="select * from "+getTableName()+"' where qty<=0;";
	System.out.println("|  pId   |    pName     |         pBrand           |    price    |  qty   |");
	try(Statement stmt=conn.createStatement())
	{
		try(ResultSet rs=stmt.executeQuery(q1))
		{
			while(rs.next())
			{
				String temp1=rs.getString(1);
				String temp2=rs.getString(2);
				String temp3=rs.getString(3);
				long temp4=rs.getLong(4);
				long temp5=rs.getLong(5);
				System.out.println("|  "+temp1+"   |  "+temp2+"  |         "+temp3+"           |    "+temp4+"    |  "+temp5+"    | ");
			}
		}
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
}
public boolean checkAvailable(String pId1)
{
	String q1="select pId from "+getTableName()+"' where qty>0 and pId='"+pId1+"';";
	String p="";
	try(Statement stmt=conn.createStatement())
	{
		try(ResultSet rs=stmt.executeQuery(q1))
		{
			while(rs.next())
			{
			p=rs.getString(1);
			}
		}
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	if(p.equals(pId1))
	{
		return true;
	}
	else
		return false;
}
}
