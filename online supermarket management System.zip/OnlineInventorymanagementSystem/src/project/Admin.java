package project;
import java.util.*;
public class Admin {
	String email;
public Admin(String email)
{
	this.email=email;
}
public void adminDashBoard()
{
	Scanner sc=new Scanner(System.in);
	boolean flag=true;
	boolean f1=true;
	while(flag)
	{
	System.out.println("Enter 1 to view or update products,2 to view or update Employee details,3 to exit");
	String ip=sc.next();
	if(ip.equals("1"))
	{
		Product emp=new Product();
		System.out.println("Do u want to update groceryProuct (g) or stationary product(s):");
		String s=sc.nextLine();
		if(s.equalsIgnoreCase("g")) 
		emp=new GroceryProduct();
		else if(s.equalsIgnoreCase("s"))
			emp=new StationaryProduct();

		while(f1)
			{
			System.out.println("Enter 1-add new product details,2-update product details,3-delete product details,4-search product,5-view Employee,6-exit");
			String n=sc.next();
			switch(n)
		{case "1":
			emp.add();
			break;
		case "2":
			emp.update();
			break;
		case "3":
			emp.delete();
			break;
		case "5":
			System.out.print("Enter 1 to view all products,2 to view available products,3 to view not available products");
			String r=sc.next();
			if(r.equalsIgnoreCase("1"))
			emp.view("all");
			else if(r.equalsIgnoreCase("2"))
				emp.view("available");
			if(r.equalsIgnoreCase("3"))
				emp.view("notavailable");
			break;
		case "6":
			f1=false;
			break;
			default:
				System.out.println("Enter coreect input");
		}
		}
		
	}
	else if(ip.equals("2"))
	{
		Employee emp=new Employee();

		while(f1)
			{
			System.out.println("Enter 1-add new employee details,2-update employee details,3-delete employee details,4-mark attendance for employee,5-search employee,6-view Employee,7-exit");
			String n=sc.next();
			switch(n)
		{case "1":
			emp.add();
			break;
		case "2":
			emp.update();
			break;
		case "3":
			emp.delete();
			break;
		case "6":
			emp.view();
			break;
		case "7":
			f1=false;
			break;
			default:
				System.out.println("Enter coreect input");
		}
		}
	}
	else if(ip.equals("3"))
	{
		flag=false;
	}
	}
	
}
}
