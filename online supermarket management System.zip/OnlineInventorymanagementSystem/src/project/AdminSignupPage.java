package project;
import java.sql.Statement;
import java.util.*;
public class AdminSignupPage extends SignUpPage {
	String enterPass="nivi";
public void adminSignUpPage()
{
	boolean flag=false;;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the admin common password:");
	String s=sc.next();
	if(s.equals(enterPass))
		flag=true;
	if(flag)
	{
		System.out.println("Enter 1 to signUp,2 to signIn,3.to exit");
		String n=sc.next();
		if(n.equals("1"))
		{
			String id=signUp();
			setEmail(id);
			if(!id.equals("")) {
				Admin ad=new Admin(getEmail());
				ad.adminDashBoard();
			}
		}
		else if(n.equals("2"))
		{
			SignUpPage ob=new AdminSignupPage();
			ob.setTableName("admin");
			String id=ob.signIn();
			setEmail(id);
			if(!id.equals("exist") && !id.equals(""))
			{
				Admin ad=new Admin(getEmail());
				ad.adminDashBoard();
			}
		}
		else if(n.equals("3"))
			flag=false;
	}
	else
		System.out.print("Wrong password");
	
}
public String signUp()
{
	Scanner sc=new Scanner(System.in);
	String id="";
	System.out.print("Enter your email id:");
	String email1=sc.next();
	setEmail(email1);
	Boolean flag=true;
	while(flag) {
	System.out.print("Enter a password:");
	String pass1=sc.next();
	System.out.println("Re enter the password");
	String pass2=sc.next();
	if(pass1.equals(pass2)) {
		Password p=new Password();
		pass1=p.hashPassword(pass1);
	setPassword(pass1);
	flag=false;
	}else
	{
		System.out.println("password doesn't match.please refill it");
	}
	}
	String sql="Insert into admin values('"+email+"','"+password+"');";
 
        try (Statement statement = conn.createStatement()) {
            	 int rowsAffected = statement.executeUpdate(sql);

                 if (rowsAffected > 0) {
                	 id=getEmail();
                 } else {
                     id="";
                 }
        } 
    catch (Exception e) {
        e.printStackTrace();
    }
	return id;
}
}
