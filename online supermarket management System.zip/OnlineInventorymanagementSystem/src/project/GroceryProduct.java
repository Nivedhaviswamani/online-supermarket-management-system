package project;

public class GroceryProduct extends Product{
	public GroceryProduct()
	{
		setTableName("grocery");
		setCategory("grocery");
	}

}
