package project;

import java.sql.Statement;
import java.util.Scanner;

public class CustomerSignupPage extends SignUpPage{
	protected String custName,address;
	long phno;
public CustomerSignupPage()
{
setTableName("customer");	
}
public String getCustName() {
    return custName;
}

public void setCustName(String custName) {
    this.custName = custName;
}


// Getter and Setter for address
public String getAddress() {
    return address;
}

public void setAddress(String address) {
    this.address = address;
}

// Getter and Setter for phno
public long getPhno() {
    return phno;
}

public void setPhno(long phno) {
    this.phno = phno;
}
public void customerSignUpPage()
{
	Scanner sc=new Scanner(System.in);
	
		System.out.println("Enter 1 to signUp,2 to signIn,3.to exit");
		String n=sc.next();
		if(n.equals("1"))
		{
			String id=signUp();
			setEmail(id);
			if(!id.equals("")) {
				Customer ad=new Customer(getEmail());
				ad.customerDashBoard();
			}
		}
		else if(n.equals("2"))
		{
			SignUpPage ob=new CustomerSignupPage();
			ob.setTableName("customer");
			String id=ob.signIn();
			setEmail(id);
			if(!id.equals("exist") && !id.equals(""))
			{
				Customer ad=new Customer(getEmail());
				ad.customerDashBoard();
			}
		}
		
	
	
}


protected String signUp()
{
	Scanner sc=new Scanner(System.in);
	String id="";
	System.out.print("Enter Customer Name: ");
    String custName1 = sc.nextLine();
    setCustName(custName1);
    System.out.print("Enter Phone Number: ");
    long phno1 = sc.nextLong();
    setPhno(phno1);
    System.out.print("Enter Address: ");
    String address1 = sc.nextLine();
    setAddress(address1);
	System.out.print("Enter your email id:");
	String email1=sc.next();
	setEmail(email1);
	Boolean flag=true;
	while(flag) {
	System.out.print("Enter a password:");
	String pass1=sc.next();
	System.out.println("Re enter the password");
	String pass2=sc.next();
	if(pass1.equals(pass2)) {
		Password p=new Password();
		pass1=p.hashPassword(pass1);
	setPassword(pass1);
	flag=false;
	}else
	{
		System.out.println("password doesn't match.please refill it");
	}
	}
	
	String sql="Insert into customer values('"+getCustName()+"','"+getPhno()+"','"+getAddress()+"','"+getEmail()+"','"+getPassword()+"');";
 
        try (Statement statement = conn.createStatement()) {
            	 int rowsAffected = statement.executeUpdate(sql);

                 if (rowsAffected > 0) {
                	 id=getEmail();
                 } else {
                     id="";
                 }
        } 
    catch (Exception e) {
        e.printStackTrace();
    }
	return id;
}
}
