package project;
import java.util.*;
import java.sql.*;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class Cart {
	Connection conn=null;
	public Cart(String email)
	{
		this.email=email;
		Connections1 c=new Connections1();
		conn=c.connect();
	}
	private String email,pId;
	private long price,qty;
	protected void setEmail(String email)
	{
		this.email=email;
	}
	protected String getEmail()
	{
		return email;
	}
	protected void setpId(String pId)
	{
		this.pId=pId;
	}
	protected String getpId()
	{
		return pId;
	}
	protected void setQty(long qty)
	{
		this.qty=qty;
	}
	protected long getQty()
	{
		return qty;
	}
public void add() {
	Scanner sc=new Scanner(System.in);
	boolean flag=true;
	String tempPId="";
	String q1="";
	long tempQty=0;
	while(flag) {
	System.out.println("Enter  n to terminate:");
	String n=sc.next();
	if(n.equalsIgnoreCase("n"))
	{
		flag=false;
		break;
	}
	System.out.println("Enter the PId of product(choose from catelogue):");
	String pId1=sc.next();
	setpId(pId1);
	System.out.println("Enter the quantity:");
	long pQty1=sc.nextLong();
	setQty(pQty1);
	Product ob=new GroceryProduct();
	Product ob2=new StationaryProduct();
	boolean available1=ob.checkAvailable(getpId());
	boolean available2=ob2.checkAvailable(getpId());
	if(!available1 || !available2)
	{
		System.out.println("you have entered the wrong PId .Enter the correct Input");
		continue;
	}
	String q2="select pId,qty from cart where pId='"+getpId()+"';";
	try(Statement stmt=conn.createStatement())
	{
		try(ResultSet rs=stmt.executeQuery(q2))
		{
			while(rs.next())
			{
				tempPId=rs.getString(1);
				tempQty=rs.getLong(2);
			}
		}
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	if(!tempPId.equals("")) {
		tempQty=tempQty+getQty();
		setQty(tempQty);
		q1="update cart set qty="+getQty()+" where pId='"+getpId()+"';";
				
	}
	else
		q1="Insert into cart values('"+getEmail()+"','"+getpId()+"','"+getQty()+"');";
		try(Statement stmt=conn.createStatement())
	{
		int rowsAffected=stmt.executeUpdate(q1);
		if(rowsAffected>0)
			System.out.println("Added to cart successfully");
		else
			System.out.println("couldn't add");
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	}
}
public void remove() {
	Scanner sc=new Scanner(System.in);
	boolean flag=true;
	String tempPId="";
	String q1="";
	long tempQty=0;
	while(flag) {
	System.out.println("Enter  n to terminate:");
	String n=sc.next();
	if(n.equalsIgnoreCase("n"))
	{
		flag=false;
		break;
	}
	System.out.println("Enter the PId of product you want to remove:");
	String pId1=sc.next();
	setpId(pId1);
	System.out.println("Do you want to remove all (a) or reduce product:");
	String req=sc.next();
	if(req.equalsIgnoreCase("a"))
		q1="delete from cart where pId='"+getpId()+"';";
	else
	{
	System.out.println("Enter the quantity you want to decrement:");
	long pQty1=sc.nextLong();
	setQty(pQty1);
	String q2="select qty from cart where pId='"+getpId()+"';";
	try(Statement stmt=conn.createStatement())
	{
		try(ResultSet rs=stmt.executeQuery(q2))
		{
			while(rs.next())
			{
				tempQty=rs.getLong(1);
			}
		}
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	if(tempQty!=0)
	{
		tempQty=tempQty-getQty();
		setQty(tempQty);
		if(tempQty>0)
			q1="update cart set qty="+getQty()+"where pId='"+getpId()+"';";
			else
				q1="delete from cart where pId='"+getpId()+"';";
	}
	}
	try(Statement stmt=conn.createStatement())
	{
		int rowsAffected=stmt.executeUpdate(q1);
		if(rowsAffected>0)
			System.out.println("Deleted to cart successfully");
		else
			System.out.println("couldn't delete");
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
}
	
}
public void placeOrder() {
	Scanner sc=new Scanner(System.in);
	String tempPId="";
	long tempQty=0,tempAvailableQty=0;
	long tempPrice=0,p=0,sum=0;
	System.out.println("Are u sure u want to place order that is available in your cart(y/n):");
	String s=sc.next();
	if(s.equalsIgnoreCase("y"))
	{
		String q2="select c.pId,c.qty,p.price,p,qty from cart c inner join product p on c.pId=p.pId where c.email='"+getEmail()+"';";
		try(Statement stmt=conn.createStatement())
		{
			try(ResultSet rs=stmt.executeQuery(q2))
			{
				while(rs.next())
				{
					tempPId=rs.getString(1);
					tempQty=rs.getInt(2);
					tempPrice=rs.getLong(3);
					tempAvailableQty=rs.getLong(4);
					long reduce=tempAvailableQty-tempQty;
					p=tempQty*tempPrice;
					sum+=p;
					String q1="update  product set qty="+reduce+" where pId='"+tempPId+"';";
					try(Statement stmt1=conn.createStatement())
				{
					int rowsAffected=stmt1.executeUpdate(q1);
					if(rowsAffected>0)
						System.out.println(tempPId+" added successfuly");
					else
						System.out.println("couldn't add");
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	String q3="Insert into orderstatus values('"+date+"','"+getEmail()+"','"+sum+"','pending');";
	try(Statement stmt3=conn.createStatement())
	{
		int rowsAffected=stmt3.executeUpdate(q3);
		if(rowsAffected>0)
			System.out.println(tempPId+" added successfuly");
		else
			System.out.println("couldn't add");
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
}
}
