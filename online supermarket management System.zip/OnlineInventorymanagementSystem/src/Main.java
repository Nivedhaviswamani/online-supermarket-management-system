
import java.sql.*;
public class Main {

public static void main(String[] args) {
		
		//Connection conn=null;
		System.out.print("A;ll");
	// TODO Auto-generated method stub
/*		try {
		Connections obj=new Connections();
		conn=obj.connect();
		try(Statement stmt = conn.createStatement())
		{
			String sql="Insert into admin values('nivi@gmail.com','Nivi@123');";
			int rowsAffected=stmt.executeUpdate(sql);
			System.out.print(rowsAffected+"Inserted");
			
		}
		conn.close();
		}
		catch(Exception e)
		{
			System.out.print(e);
			//e.printStackTrace();
		}*/
	}

}
