/**
 * 
 */
/**
 * 
 */
module NewVehicle {
}